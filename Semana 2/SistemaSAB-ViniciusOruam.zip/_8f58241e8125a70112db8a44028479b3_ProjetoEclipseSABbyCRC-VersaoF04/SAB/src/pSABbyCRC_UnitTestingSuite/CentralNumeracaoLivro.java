package pSABbyCRC_UnitTestingSuite;

public class CentralNumeracaoLivro {
	private int _nrUnico = 0;
}
