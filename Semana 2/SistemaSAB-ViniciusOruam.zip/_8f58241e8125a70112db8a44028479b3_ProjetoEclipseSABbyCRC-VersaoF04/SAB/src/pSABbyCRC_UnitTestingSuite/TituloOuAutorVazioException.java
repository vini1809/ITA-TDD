package pSABbyCRC_UnitTestingSuite;

@SuppressWarnings("serial")
public class TituloOuAutorVazioException extends Exception {
	public TituloOuAutorVazioException(String message)
    {
       super(message);
    }
}