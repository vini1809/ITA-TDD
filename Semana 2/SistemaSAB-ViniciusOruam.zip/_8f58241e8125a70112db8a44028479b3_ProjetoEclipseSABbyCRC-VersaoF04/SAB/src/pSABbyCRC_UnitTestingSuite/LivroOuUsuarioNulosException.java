package pSABbyCRC_UnitTestingSuite;

@SuppressWarnings("serial")
public class LivroOuUsuarioNulosException extends Exception {
	public LivroOuUsuarioNulosException(String message)
    {
       super(message);
    }
}